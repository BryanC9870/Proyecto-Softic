package VISTA;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import CONTROLADOR.ConexionMysql;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import javax.swing.JSpinner;
/**
 *
 * @author ADSI
 */
public class IngresarCredito extends javax.swing.JInternalFrame {
private SimpleDateFormat formato;
public static Connection connection; 
  public static Statement sentencia; 
    /**
     * Creates new form IngresarCredito
     */
    public IngresarCredito() {
        initComponents();
        CajaPlaca.setEnabled(true);
         
            if(CajaTipo.getSelectedItem().toString().equals("NUEVO"))
        {
            BtnIngresarUsado.setEnabled(false);
             BtnIngresarNuevo.setEnabled(true);
             CajaPlaca.setEnabled(false);
//             CajaReferencia.setEnabled(true);
        }  
            
      
          
         formato = ((JSpinner.DateEditor) CajaFecha.getEditor()).getFormat();
        formato.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        formato.applyPattern("yyyy-MM-dd");
        CargarVendedores ();
        CargarFinanciera();
    
    }
    public int ValidarIngresos(String Placa)
    {
        int esta=1;
        
      try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from vehiculo where IDPlaca='"+Placa+"'");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
       
        
         while (resultado.next()) 
         {
          CajaReferencia.setText(resultado.getString("Referencia"));
           esta =0;
         }
         
             
         
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
        
        return esta;
    }
     public void limpiarcajas()
{
    CajaCedulaCliente.setText("");
    CajaPlaca.setText("");
    CajaCapacidad.setText("");
    CajaObservaciones.setText("");
    CajaNombre.setText("");
    CajaApellido.setText("");
   CajaReferencia.setText("");
    
}
     public void CargarVendedores()
     {
          if(CajaTipo.getSelectedItem().toString().equals("USADO"))
        {
            BtnIngresarUsado.setEnabled(true);
             BtnIngresarNuevo.setEnabled(false);
             
           
        }
         
           try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from vendedor where Estado='ACTIVO' order by IDVendedor");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
         
         while (resultado.next()) 
         {
           CajaVendedor.addItem(resultado.getString("IDVendedor")+"- "+resultado.getString(2)+" "+resultado.getString(3));
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
     }
    public void CargarFinanciera()
     {
           try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from financiera where Estado='ACTIVO' order by IDFinanciera");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
         
         while (resultado.next()) 
         {
           CajaFinanciera.addItem(resultado.getString("IDFinanciera")+"- "+resultado.getString(2));
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
         
       
             
           
        
      }
     }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        CajaCedulaCliente = new javax.swing.JTextField();
        CajaEstado = new javax.swing.JComboBox<>();
        CajaVendedor = new javax.swing.JComboBox<>();
        CajaPlaca = new javax.swing.JTextField();
        CajaFinanciera = new javax.swing.JComboBox<>();
        CajaCapacidad = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        CajaObservaciones = new javax.swing.JTextArea();
        CajaFecha = new javax.swing.JSpinner();
        BtnIngresarUsado = new javax.swing.JButton();
        CajaApellido = new javax.swing.JTextField();
        CajaNombre = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        BtnIngresarNuevo = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        CajaReferencia = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        CajaTipo = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Ingresar Credito");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameIconified(evt);
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel2.setText("APELLIDOS");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel3.setText("ESTADO DEL CREDITO");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel4.setText("CEDULA VENDEDOR");

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel5.setText("OBSERVACIONES");

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel6.setText("FINANCIERA");

        jLabel7.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel7.setText("PLACA ");

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel8.setText("FECHA");

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel9.setText("CAPACIDAD ENDEUDAMIENTO");

        CajaCedulaCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                CajaCedulaClienteFocusLost(evt);
            }
        });
        CajaCedulaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaCedulaClienteActionPerformed(evt);
            }
        });
        CajaCedulaCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaCedulaClienteKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CajaCedulaClienteKeyTyped(evt);
            }
        });

        CajaEstado.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        CajaEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "EN ESTUDIO", "APROBADO", "NEGADO", "DESEMBOLSADO" }));

        CajaVendedor.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        CajaVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaVendedorActionPerformed(evt);
            }
        });

        CajaPlaca.setEnabled(false);
        CajaPlaca.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                CajaPlacaFocusLost(evt);
            }
        });
        CajaPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaPlacaActionPerformed(evt);
            }
        });
        CajaPlaca.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaPlacaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CajaPlacaKeyTyped(evt);
            }
        });

        CajaFinanciera.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N

        CajaCapacidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CajaCapacidadKeyTyped(evt);
            }
        });

        CajaObservaciones.setColumns(20);
        CajaObservaciones.setRows(5);
        jScrollPane1.setViewportView(CajaObservaciones);

        CajaFecha.setModel(new javax.swing.SpinnerDateModel());

        BtnIngresarUsado.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        BtnIngresarUsado.setText("Ingresar Usados");
        BtnIngresarUsado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnIngresarUsadoActionPerformed(evt);
            }
        });

        CajaApellido.setEditable(false);
        CajaApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaApellidoKeyPressed(evt);
            }
        });

        CajaNombre.setEditable(false);
        CajaNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaNombreKeyPressed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel10.setText("CEDULA CLIENTE");

        jLabel11.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel11.setText("NOMBRES");

        BtnIngresarNuevo.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        BtnIngresarNuevo.setText("Ingresar Nuevos");
        BtnIngresarNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnIngresarNuevoActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel12.setText("REFERENCIA");

        CajaReferencia.setEnabled(false);
        CajaReferencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaReferenciaKeyPressed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel13.setText("TIPODEVEHICULO");

        CajaTipo.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        CajaTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "USADO", "NUEVO" }));
        CajaTipo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                CajaTipoItemStateChanged(evt);
            }
        });
        CajaTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaTipoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(118, 118, 118))
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(BtnIngresarUsado)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(CajaFecha, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 248, Short.MAX_VALUE)
                        .addComponent(CajaCapacidad, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(CajaFinanciera, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(CajaPlaca)
                    .addComponent(CajaReferencia)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(BtnIngresarNuevo)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1)
                    .addComponent(CajaVendedor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CajaEstado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CajaApellido)
                    .addComponent(CajaNombre)
                    .addComponent(CajaCedulaCliente)
                    .addComponent(CajaTipo, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(243, 243, 243))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addComponent(CajaTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(CajaCedulaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(CajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(CajaApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(CajaEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(CajaVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(CajaPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(CajaReferencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(CajaFinanciera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(CajaCapacidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(CajaFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnIngresarUsado)
                    .addComponent(BtnIngresarNuevo))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private int RevisarCajitas()
{
    int ok=1;
    
    if (CajaCedulaCliente.getText().equals("")){ok=0;}
     if (CajaPlaca.getText().equals("")){ok=0;}
      if (CajaCapacidad.getText().equals("")){ok=0;}
       if (CajaObservaciones.getText().equals("")){ok=0;}
     
    return ok;
}
       private int RevisarCajitas2()
{
    int ok=1;
    
    if (CajaCedulaCliente.getText().equals("")){ok=0;}
//     if (CajaReferencia.getText().equals("")){ok=0;}
      if (CajaCapacidad.getText().equals("")){ok=0;}

     
    return ok;
}
    private void BtnIngresarUsadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnIngresarUsadoActionPerformed
        // TODO add your handling code here:
         String z;
       z=CajaVendedor.getSelectedItem().toString();
       int i = z.indexOf("-");
       String s=z.substring(0,i);
       
       String r;
       r=CajaFinanciera.getSelectedItem().toString();
       int j= r.indexOf("-");
       String p=r.substring(0,j);
       
       
       String x;
       x=new SimpleDateFormat("yyyy/MM/dd").format(CajaFecha.getValue());
        if(RevisarCajitas()==1){ 
        try {
        
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia;
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         sentencia.executeUpdate("insert into estudiodecredito(IDCedula,EstadoCredito,IDVendedor,IDVehiculo,IDFinanciera,CapacidadDeEndeudamiento,Observaciones,Fecha)values('"+CajaCedulaCliente.getText()+"','"+CajaEstado.getSelectedItem().toString().toUpperCase()+"','"+s+"','"+CajaPlaca.getText().toUpperCase()+"','"+p+"','"+CajaCapacidad.getText()+"','"+CajaObservaciones.getText().toUpperCase()+"','"+x+"');");    
             
         
         JOptionPane.showMessageDialog(null,"El Credito De "+ CajaCedulaCliente.getText() +" fue almacenado");
         ConectBD.Cerrar();
         limpiarcajas();
        }
         
          catch (SQLException ex) {
          Logger.getLogger(IngresarClientes.class.getName()).log(Level.SEVERE, null, ex);
      } }// FIn del If
        else{
        JOptionPane.showMessageDialog(null,"Diligencie Correctamente Las cajas de Texto ");}
    }//GEN-LAST:event_BtnIngresarUsadoActionPerformed

    private void CajaCedulaClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaCedulaClienteKeyPressed
        // TODO add your handling code here:
          if (CajaCedulaCliente.getText().length() >= 11) {
            CajaCedulaCliente.setText("");//Limpiar el caracter ingresado
             JOptionPane.showMessageDialog(null, "Ha excedido el numero maximo de caracteres!!! (11)", "Validando Datos",
                     JOptionPane.ERROR_MESSAGE);
         }
        
    }//GEN-LAST:event_CajaCedulaClienteKeyPressed

    private void CajaPlacaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaPlacaKeyPressed
        // TODO add your handling code here:
          if (CajaPlaca.getText().length() >= 7) {
            CajaPlaca.setText("");//Limpiar el caracter ingresado
             JOptionPane.showMessageDialog(null, "Ha excedido el numero maximo de caracteres!!! (06)", "Validando Datos",
                     JOptionPane.ERROR_MESSAGE);
         }
    }//GEN-LAST:event_CajaPlacaKeyPressed

    private void CajaCedulaClienteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaCedulaClienteKeyTyped
        // TODO add your handling code here:
          char letra = evt.getKeyChar();
        if(!(Character.isDigit(letra))){
            evt.consume();
        }
    }//GEN-LAST:event_CajaCedulaClienteKeyTyped

    private void CajaCapacidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaCapacidadKeyTyped
        // TODO add your handling code here:
          char letra = evt.getKeyChar();
        if(!(Character.isDigit(letra))){
            evt.consume();
        }
    }//GEN-LAST:event_CajaCapacidadKeyTyped

    private void CajaApellidoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaApellidoKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaApellidoKeyPressed

    private void CajaNombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaNombreKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaNombreKeyPressed

    private void CajaCedulaClienteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CajaCedulaClienteFocusLost
        // TODO add your handling code here:
         
    }//GEN-LAST:event_CajaCedulaClienteFocusLost

    private void BtnIngresarNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnIngresarNuevoActionPerformed
        // TODO add your handling code here:
         String z;
       z=CajaVendedor.getSelectedItem().toString();
       int i = z.indexOf("-");
       String s=z.substring(0,i);
       
       String r;
       r=CajaFinanciera.getSelectedItem().toString();
       int j= r.indexOf("-");
       String p=r.substring(0,j);
       
       
       String x;
       x=new SimpleDateFormat("yyyy/MM/dd").format(CajaFecha.getValue());
        if(RevisarCajitas2()==1){ 
        try {
        
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia;
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         sentencia.executeUpdate("insert into estudiodecreditonuevos(IDCedula,EstadoCredito,IDVendedor,Referencia,IDFinanciera,CapacidadDeEndeudamiento,Observaciones,Fecha)values('"+CajaCedulaCliente.getText()+"','"+CajaEstado.getSelectedItem().toString().toUpperCase()+"','"+s+"','"+CajaReferencia.getText().toUpperCase()+"','"+p+"','"+CajaCapacidad.getText()+"','"+CajaObservaciones.getText().toUpperCase()+"','"+x+"');");    
             
         
         JOptionPane.showMessageDialog(null,"El Credito del cliente con numero de cedula "+ CajaCedulaCliente.getText() +" fue almacenado");
         ConectBD.Cerrar();
         limpiarcajas();
        }
         
          catch (SQLException ex) {
          Logger.getLogger(IngresarClientes.class.getName()).log(Level.SEVERE, null, ex);
      } }// FIn del If
        else{
        JOptionPane.showMessageDialog(null,"Diligencie Correctamente Las cajas de Texto ");}
        
    }//GEN-LAST:event_BtnIngresarNuevoActionPerformed

    private void CajaTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaTipoActionPerformed
        // TODO add your handling code here:
       if(CajaTipo.getSelectedItem().toString().equals("NUEVO"))
        {
            BtnIngresarUsado.setEnabled(false);
             BtnIngresarNuevo.setEnabled(true);
              CajaPlaca.setEnabled(false);
              CajaReferencia.setEnabled(true);
             
           
        }
       if(CajaTipo.getSelectedItem().toString().equals("USADO"))
        {
            BtnIngresarUsado.setEnabled(true);
             BtnIngresarNuevo.setEnabled(false);
             CajaPlaca.setEnabled(true);
             CajaReferencia.setEnabled(false);
             
            
             
           
        }
    }//GEN-LAST:event_CajaTipoActionPerformed

    private void CajaVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaVendedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaVendedorActionPerformed

    private void CajaReferenciaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaReferenciaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaReferenciaKeyPressed

    private void CajaPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaPlacaActionPerformed
        // TODO add your handling code here:
          int x=0;
        x=ValidarIngresos(CajaPlaca.getText());
        if(x==0){
            
            
           
          
            
        }
        else{
            JOptionPane.showMessageDialog(null, "El Numero de Placa No existe en la base de datos de los vehiculos.","ADVERTENCIA",
                     JOptionPane.ERROR_MESSAGE);
            
            CajaPlaca.setText("");
            
        }
        
    }//GEN-LAST:event_CajaPlacaActionPerformed

    private void CajaPlacaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CajaPlacaFocusLost
        // TODO add your handling code here:
      
    }//GEN-LAST:event_CajaPlacaFocusLost

    private void CajaPlacaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaPlacaKeyTyped
        // TODO add your handling code here:
        char letra=evt.getKeyChar();
        if(Character.isLowerCase(letra))
        {
            
           String cad=(""+letra).toString().toUpperCase();
           letra=cad.charAt(0);
           evt.setKeyChar(letra);
        
        }
    }//GEN-LAST:event_CajaPlacaKeyTyped

    private void CajaTipoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_CajaTipoItemStateChanged
        // TODO add your handling code here:
        limpiarcajas();
    }//GEN-LAST:event_CajaTipoItemStateChanged

    private void formInternalFrameIconified(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameIconified
        // TODO add your handling code here:
          this.toFront();
    }//GEN-LAST:event_formInternalFrameIconified

    private void CajaCedulaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaCedulaClienteActionPerformed
        // TODO add your handling code here:
         try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from cliente where Estado='ACTIVO' AND IDCedula='"+CajaCedulaCliente.getText()+"'");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
       
         int esta=0;
         while (resultado.next()) 
         {
           CajaNombre.setText(resultado.getString("Nombres"));
           CajaApellido.setText(resultado.getString("Apellidos"));
           esta =1;
         }
         if(esta==0){
             JOptionPane.showMessageDialog(null, "El Cliente No Esta Registrado");
             limpiarcajas();
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
    }//GEN-LAST:event_CajaCedulaClienteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnIngresarNuevo;
    private javax.swing.JButton BtnIngresarUsado;
    private javax.swing.JTextField CajaApellido;
    private javax.swing.JTextField CajaCapacidad;
    private javax.swing.JTextField CajaCedulaCliente;
    private javax.swing.JComboBox<String> CajaEstado;
    private javax.swing.JSpinner CajaFecha;
    private javax.swing.JComboBox<String> CajaFinanciera;
    private javax.swing.JTextField CajaNombre;
    private javax.swing.JTextArea CajaObservaciones;
    private javax.swing.JTextField CajaPlaca;
    private javax.swing.JTextField CajaReferencia;
    private javax.swing.JComboBox<String> CajaTipo;
    private javax.swing.JComboBox<String> CajaVendedor;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
