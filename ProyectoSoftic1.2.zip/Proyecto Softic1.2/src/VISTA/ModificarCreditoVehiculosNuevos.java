package VISTA;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import CONTROLADOR.ConexionMysql;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import javax.swing.JSpinner;
/**
 *
 * @author ADSI
 */
public class ModificarCreditoVehiculosNuevos extends javax.swing.JInternalFrame {
private SimpleDateFormat formato;
public static Connection connection; 
  public static Statement sentencia; 
    /**
     * Creates new form IngresarCredito
     */
    public ModificarCreditoVehiculosNuevos() {
       
   
        initComponents();
         
        BtnIngresarUsado.setEnabled(false);
        CajaReferencia.setEnabled(true);
         
            
      
          
         formato = ((JSpinner.DateEditor) CajaFecha.getEditor()).getFormat();
        formato.setTimeZone(TimeZone.getTimeZone("America/New_York"));
        formato.applyPattern("yyyy-MM-dd");
        CargarVendedores ();
        CargarFinanciera();
    
    }
     public void limpiarcajas()
{
    CajaCedulaCliente.setText("");
    CajaReferencia.setText("");
    CajaCapacidad.setText("");
    CajaObservaciones.setText("");
    CajaNombre.setText("");
    CajaApellido.setText("");
    CajaEstudiosCredito.setSelectedItem("");
    CajaEstado1.setSelectedItem("");
    CajaFinanciera.setSelectedItem("");
//   
    
}
     public void CargarVendedores()
     {
         
         
           try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from vendedor where Estado='ACTIVO' order by IDVendedor");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
         
         while (resultado.next()) 
         {
           CajaVendedor.addItem(resultado.getString("IDVendedor")+"- "+resultado.getString(2)+" "+resultado.getString(3));
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
     }
    public void CargarFinanciera()
     {
           try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from financiera where Estado='ACTIVO' order by IDFinanciera");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
         
         while (resultado.next()) 
         {
           CajaFinanciera.addItem(resultado.getString("IDFinanciera")+"- "+resultado.getString(2));
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
         
       
             
           
        
      }
     }
    public  void CargarEstudios()
     {
       
           try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from estudiodecreditonuevos   where IDCedula='"+CajaCedulaCliente.getText()+ "'"+"ORDER BY IDCredito ASC");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
         
         while (resultado.next()) 
         {
           CajaEstudiosCredito.addItem(resultado.getString("IDCredito")+"- "+resultado.getString(4)+" "+resultado.getString(3));
         //  CajaEstado1.setSelectedItem(resultado.getString(3));
           //CajaVendedor.setSelectedItem(resultado.getString(4));
           //CajaPlaca.setText(resultado.getString(5));
           //CajaFinanciera.setSelectedItem(resultado.getString(6));
          // CajaCapacidad.setText(resultado.getString(7));
         
        //   CajaFecha.setValue("2017/08/30");
           /*Date date1 = new Date();
            date1.setMonth(6);
            date1.setYear(2017);
            date1.setDay(23);*/
           //CajaFecha.setValue(resultado.getDate("Fecha"));
          // CajaObservaciones.setText(resultado.getString(8));
           
         }
         ConectBD.Cerrar();
         

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
     }
    public  void CargarEstudios2()
     {
       
           try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from estudiodecreditonuevos   where IDCedula='"+CajaCedulaCliente.getText()+ "'"+"ORDER BY IDCredito ASC");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
         
         while (resultado.next()) 
         {
          // CajaEstudiosCredito.addItem(resultado.getString("IDCredito")+"- "+resultado.getString(4)+" "+resultado.getString(3));
           CajaEstado1.setSelectedItem(resultado.getString(3));
           CajaVendedor.setSelectedItem(resultado.getString(4));
           CajaReferencia.setText(resultado.getString(5));
           CajaFinanciera.setSelectedItem(resultado.getString(6));
          CajaCapacidad.setText(resultado.getString(7));
         
        //   CajaFecha.setValue("2017/08/30");
           /*Date date1 = new Date();
            date1.setMonth(6);
            date1.setYear(2017);
            date1.setDay(23);*/
           CajaFecha.setValue(resultado.getDate("Fecha"));
           CajaObservaciones.setText(resultado.getString(8));
           
         }
         ConectBD.Cerrar();
         

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
     
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        CajaCedulaCliente = new javax.swing.JTextField();
        CajaEstudiosCredito = new javax.swing.JComboBox<>();
        CajaVendedor = new javax.swing.JComboBox<>();
        CajaReferencia = new javax.swing.JTextField();
        CajaFinanciera = new javax.swing.JComboBox<>();
        CajaCapacidad = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        CajaObservaciones = new javax.swing.JTextArea();
        CajaFecha = new javax.swing.JSpinner();
        BtnIngresarUsado = new javax.swing.JButton();
        CajaApellido = new javax.swing.JTextField();
        CajaNombre = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        CajaEstado1 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        etirecorte = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Modificar Credito Vehiculos Nuevos");
        setToolTipText("");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameIconified(evt);
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel2.setText("APELLIDOS");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel3.setText("ESTADO DEL CREDITO");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel4.setText("CEDULA VENDEDOR");

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel5.setText("OBSERVACIONES");

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel6.setText("FINANCIERA");

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel8.setText("FECHA");

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel9.setText("CAPACIDAD ENDEUDAMIENTO");

        CajaCedulaCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                CajaCedulaClienteFocusLost(evt);
            }
        });
        CajaCedulaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaCedulaClienteActionPerformed(evt);
            }
        });
        CajaCedulaCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaCedulaClienteKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CajaCedulaClienteKeyTyped(evt);
            }
        });

        CajaEstudiosCredito.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        CajaEstudiosCredito.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                CajaEstudiosCreditoItemStateChanged(evt);
            }
        });
        CajaEstudiosCredito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                CajaEstudiosCreditoMouseReleased(evt);
            }
        });
        CajaEstudiosCredito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaEstudiosCreditoActionPerformed(evt);
            }
        });

        CajaVendedor.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        CajaVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaVendedorActionPerformed(evt);
            }
        });

        CajaReferencia.setEnabled(false);
        CajaReferencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaReferenciaKeyPressed(evt);
            }
        });

        CajaFinanciera.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N

        CajaCapacidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CajaCapacidadKeyTyped(evt);
            }
        });

        CajaObservaciones.setColumns(20);
        CajaObservaciones.setRows(5);
        jScrollPane1.setViewportView(CajaObservaciones);

        CajaFecha.setModel(new javax.swing.SpinnerDateModel());

        BtnIngresarUsado.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        BtnIngresarUsado.setText("Modificar ");
        BtnIngresarUsado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnIngresarUsadoActionPerformed(evt);
            }
        });

        CajaApellido.setEditable(false);
        CajaApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaApellidoActionPerformed(evt);
            }
        });
        CajaApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaApellidoKeyPressed(evt);
            }
        });

        CajaNombre.setEditable(false);
        CajaNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CajaNombreKeyPressed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel10.setText("CEDULA CLIENTE");

        jLabel11.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel11.setText("NOMBRES");

        CajaEstado1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        CajaEstado1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "EN ESTUDIO", "APROBADO", "NEGADO", "DESEMBOLSADO" }));

        jLabel14.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel14.setText("ESTUDIOS CLIENTE");

        jLabel12.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel12.setText("REFERENCIA");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10)
                    .addComponent(jLabel14)
                    .addComponent(jLabel12)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8)
                    .addComponent(jLabel5))
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(CajaEstado1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(54, 54, 54)
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(CajaEstudiosCredito, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(etirecorte, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(207, 207, 207))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(CajaCapacidad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                                .addComponent(CajaFecha, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                                .addComponent(CajaFinanciera, javax.swing.GroupLayout.Alignment.TRAILING, 0, 214, Short.MAX_VALUE)
                                .addComponent(CajaReferencia, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                                .addComponent(CajaNombre)
                                .addComponent(CajaCedulaCliente))
                            .addComponent(CajaApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CajaVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addComponent(BtnIngresarUsado, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel1)
                            .addComponent(etirecorte, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(CajaCedulaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(CajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(CajaApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CajaEstudiosCredito))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(CajaEstado1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(CajaVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(CajaReferencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(CajaFinanciera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(CajaCapacidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(CajaFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel5)))
                .addGap(30, 30, 30)
                .addComponent(BtnIngresarUsado)
                .addGap(28, 28, 28))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private int RevisarCajitas()
{
    int ok=1;
    
    if (CajaCedulaCliente.getText().equals("")){ok=0;}
     if (CajaReferencia.getText().equals("")){ok=0;}
      if (CajaCapacidad.getText().equals("")){ok=0;}
       if (CajaObservaciones.getText().equals("")){ok=0;}
     
    return ok;
}
       private int RevisarCajitas2()
{
    int ok=1;
    
    if (CajaCedulaCliente.getText().equals("")){ok=0;}
     
      if (CajaCapacidad.getText().equals("")){ok=0;}

     
    return ok;
}
    private void BtnIngresarUsadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnIngresarUsadoActionPerformed
        // TODO add your handling code here:
         String z;
       z=CajaVendedor.getSelectedItem().toString();
       int i = z.indexOf("-");
       String s=z.substring(0,i);
       
       String r;
       r=CajaFinanciera.getSelectedItem().toString();
       int j= r.indexOf("-");
       String p=r.substring(0,j);
       
       
       String x;
       x=new SimpleDateFormat("yyyy/MM/dd").format(CajaFecha.getValue());
        String e;
       e=CajaEstudiosCredito.getSelectedItem().toString();
       int u = e.indexOf("-");
        String es=e.substring(0,u);
        System.out.println(es);
        if(RevisarCajitas()==1){ 
        try {
        System.out.println("Estoy Dentro de el Try");
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia;
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
          // System.out.println("UPDATE  estudiodecredito  set EstadoCredito='"+CajaEstado1.getSelectedItem().toString().toUpperCase()+"',IDVendedor='"+s+"',IDVehiculo='"+CajaPlaca.getText().toUpperCase()+"',IDFinanciera='"+p+"',CapacidadDeEndeudamiento='"+CajaCapacidad.getText()+"',Observaciones='"+CajaObservaciones.getText().toUpperCase()+"',Fecha='"+x+"',Referencia='"+"'where IDCredito='"+es+"'");
         sentencia.executeUpdate("UPDATE  estudiodecreditonuevos  set EstadoCredito='"+CajaEstado1.getSelectedItem().toString().toUpperCase()+"',IDVendedor='"+s+"',Referencia='"+CajaReferencia.getText().toUpperCase()+"', IDFinanciera='"+p+"', CapacidadDeEndeudamiento='"+CajaCapacidad.getText()+"', Observaciones='"+CajaObservaciones.getText().toUpperCase()+"',Fecha='"+x+"' where IDCredito='"+es+"'");    
           
         
         JOptionPane.showMessageDialog(null,"El Credito De "+ CajaCedulaCliente.getText() +" fue almacenado");
         ConectBD.Cerrar();
         limpiarcajas();
         this.dispose();
        }
         
          catch (SQLException ex) {
          Logger.getLogger(IngresarClientes.class.getName()).log(Level.SEVERE, null, ex);
          System.out.println("Estoy Dentro de el catch");
      } }// FIn del If
        else{
        JOptionPane.showMessageDialog(null,"Diligencie Correctamente Las cajas de Texto ");}
    }//GEN-LAST:event_BtnIngresarUsadoActionPerformed

    private void CajaCedulaClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaCedulaClienteKeyPressed
        // TODO add your handling code here:
          if (CajaCedulaCliente.getText().length() >= 11) {
            CajaCedulaCliente.setText("");//Limpiar el caracter ingresado
             JOptionPane.showMessageDialog(null, "Ha excedido el numero maximo de caracteres!!! (11)", "Validando Datos",
                     JOptionPane.ERROR_MESSAGE);
         }
        
    }//GEN-LAST:event_CajaCedulaClienteKeyPressed

    private void CajaReferenciaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaReferenciaKeyPressed
        // TODO add your handling code here:
          if (CajaReferencia.getText().length() >= 6) {
            CajaReferencia.setText("");//Limpiar el caracter ingresado
             JOptionPane.showMessageDialog(null, "Ha excedido el numero maximo de caracteres!!! (6)", "Validando Datos",
                     JOptionPane.ERROR_MESSAGE);
         }
    }//GEN-LAST:event_CajaReferenciaKeyPressed

    private void CajaCedulaClienteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaCedulaClienteKeyTyped
        // TODO add your handling code here:
          char letra = evt.getKeyChar();
        if(!(Character.isDigit(letra))){
            evt.consume();
        }
    }//GEN-LAST:event_CajaCedulaClienteKeyTyped

    private void CajaCapacidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaCapacidadKeyTyped
        // TODO add your handling code here:
          char letra = evt.getKeyChar();
        if(!(Character.isDigit(letra))){
            evt.consume();
        }
    }//GEN-LAST:event_CajaCapacidadKeyTyped

    private void CajaApellidoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaApellidoKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaApellidoKeyPressed

    private void CajaNombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CajaNombreKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaNombreKeyPressed

    private void CajaCedulaClienteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CajaCedulaClienteFocusLost
        // TODO add your handling code here:
       
    }//GEN-LAST:event_CajaCedulaClienteFocusLost

    private void CajaVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaVendedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaVendedorActionPerformed

    private void CajaEstudiosCreditoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaEstudiosCreditoActionPerformed
        // TODO add your handling code here:
      
 
        
    }//GEN-LAST:event_CajaEstudiosCreditoActionPerformed

    private void CajaCedulaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaCedulaClienteActionPerformed
        // TODO add your handling code here:
         CargarEstudios();
        try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from cliente where Estado='ACTIVO' AND IDCedula='"+CajaCedulaCliente.getText()+"'");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
       
         int esta=0;
         while (resultado.next()) 
         {
           CajaNombre.setText(resultado.getString("Nombres"));
           CajaApellido.setText(resultado.getString("Apellidos"));
           esta =1;
           BtnIngresarUsado.setEnabled(true);
         }
         if(esta==0){
             JOptionPane.showMessageDialog(null, "El Cliente No Esta Registrado");
             limpiarcajas();
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
        
    }//GEN-LAST:event_CajaCedulaClienteActionPerformed

    private void CajaEstudiosCreditoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_CajaEstudiosCreditoItemStateChanged
        // TODO add your handling code here:
               String e;
       e=CajaEstudiosCredito.getSelectedItem().toString();
       int l = e.indexOf("-");
       String es=e.substring(0,l);
       try {
         ConexionMysql ConectBD=new ConexionMysql();
         Statement sentencia; // st
         ResultSet resultado; //rs 
         
         ConectBD.IniciarConexion();
         Connection conn=ConectBD.getMyConnection();
         sentencia= conn.createStatement();
         
        // JOptionPane.showMessageDialog(null,"La consulta sera"+comandosql);
         resultado = sentencia.executeQuery("select * from estudiodecreditonuevos where IDCredito='"+es+"'");
         ResultSetMetaData meta = resultado.getMetaData();
         int columnas = meta.getColumnCount();  //Mientras haya registros 
       
         int esta=0;
         while (resultado.next()) 
         {
           CajaEstado1.setSelectedItem(resultado.getString("EstadoCredito"));
           CajaVendedor.setSelectedItem(resultado.getString("IDVendedor"));
           CajaReferencia.setText(resultado.getString("Referencia"));
            CajaFinanciera.setSelectedItem(resultado.getString("IDFinanciera"));
           CajaCapacidad.setText(resultado.getString("CapacidadDeEndeudamiento"));
           CajaFecha.setValue(resultado.getDate("Fecha"));
           CajaObservaciones.setText(resultado.getString("Observaciones"));
           esta =1;
         }
         if(esta==0){
             JOptionPane.showMessageDialog(null, "El Cliente No Esta Registrado");
             limpiarcajas();
         }
         ConectBD.Cerrar();

 //        JOptionPane.showMessageDialog(null,"La consulta fue realizada");
      } catch (SQLException ex) {
          Logger.getLogger(IngresarCotizacion.class.getName()).log(Level.SEVERE, null, ex);
      }
       
       
      
    }//GEN-LAST:event_CajaEstudiosCreditoItemStateChanged

    private void CajaApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaApellidoActionPerformed

    private void CajaEstudiosCreditoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CajaEstudiosCreditoMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaEstudiosCreditoMouseReleased

    private void formInternalFrameIconified(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameIconified
        // TODO add your handling code here:
          this.toFront();
    }//GEN-LAST:event_formInternalFrameIconified


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnIngresarUsado;
    private javax.swing.JTextField CajaApellido;
    private javax.swing.JTextField CajaCapacidad;
    private javax.swing.JTextField CajaCedulaCliente;
    private javax.swing.JComboBox<String> CajaEstado1;
    private javax.swing.JComboBox<String> CajaEstudiosCredito;
    private javax.swing.JSpinner CajaFecha;
    private javax.swing.JComboBox<String> CajaFinanciera;
    private javax.swing.JTextField CajaNombre;
    private javax.swing.JTextArea CajaObservaciones;
    private javax.swing.JTextField CajaReferencia;
    private javax.swing.JComboBox<String> CajaVendedor;
    private javax.swing.JLabel etirecorte;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
